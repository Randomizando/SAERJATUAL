-- AlterTable
ALTER TABLE `Associados` ADD COLUMN `data_ultimo_envio_email_aniversario` DATETIME(3) NULL;
