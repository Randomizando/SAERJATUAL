import { styled } from '@ignite-ui/react'
export const Container = styled('div', {
  border: 'solid 1px #A9A9B2',
  borderTop: 'transparent',
  borderLeft: 'transparent',
  borderRight: 'transparent',
  borderRadius: '0px',
  paddingBottom: '0px',
})
