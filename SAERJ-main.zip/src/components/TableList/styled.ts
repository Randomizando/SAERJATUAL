import { styled } from '@ignite-ui/react'

export const Container = styled('div', {
  '.css-ptiqhd-MuiSvgIcon-root': {
    color: 'rgb(13, 169, 164)',
  },
  '.css-ptkaw2-MuiDataGrid-root .MuiDataGrid-columnHeader--alignCenter .MuiDataGrid-columnHeaderTitleContainer': {
    display: 'none',
  },
})
