import { styled } from '@ignite-ui/react'

export const Container = styled('div', {
  border: 'solid red',
})
