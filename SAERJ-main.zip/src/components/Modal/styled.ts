import { styled } from '@ignite-ui/react'
import Modal from '@mui/material/Modal'
export const Container = styled(Modal, {})
